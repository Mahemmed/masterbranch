package com.samplecode.springboot.cruddemo.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "employee")
public class Employee {

	// define fields

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "name")
	@NotNull
	@Size(max=3)
	private String name;

	@Column(name = "date_of_birth")
	private Date dateOfBirth;


	public Employee() {

	}
	
	public Employee(Long id, String name, Date dateOfBirth) {
		super();
		this.id = id;
		this.name = name;
		this.dateOfBirth = dateOfBirth;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	@ManyToMany(cascade = { CascadeType.ALL })
	@JoinTable(
			name="course_student",
			joinColumns=@JoinColumn(name="address_id"),
			inverseJoinColumns=@JoinColumn(name="employee_id")
			)	
	private List<Address> address;


	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", dateOfBirth="
				+ dateOfBirth + ", address=" + address + "]";
	}

}
