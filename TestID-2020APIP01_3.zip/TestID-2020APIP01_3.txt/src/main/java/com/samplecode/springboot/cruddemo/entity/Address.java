package com.samplecode.springboot.cruddemo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "address")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "addrId")
	private Long addr_id;

	@Column(name = "addrLineOne")
	@NotNull
	@Size(max=5)
	private String addr_line_one;

	@Column(name = "addrLineTwo")
	private String addr_line_two;

	@Column(name = "city")
	@NotNull
	private String city;

	public Address() {

	}

	public Address(Long addr_id, String addr_line_one, String addr_line_two,
			String city) {
		super();
		this.addr_id = addr_id;
		this.addr_line_one = addr_line_one;
		this.addr_line_two = addr_line_two;
		this.city = city;
	}

	public Long getAddr_id() {
		return addr_id;
	}

	public void setAddr_id(Long addr_id) {
		this.addr_id = addr_id;
	}

	public String getAddr_line_one() {
		return addr_line_one;
	}

	public void setAddr_line_one(String addr_line_one) {
		this.addr_line_one = addr_line_one;
	}

	public String getAddr_line_two() {
		return addr_line_two;
	}

	public void setAddr_line_two(String addr_line_two) {
		this.addr_line_two = addr_line_two;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@ManyToMany(cascade = { CascadeType.ALL })
	@JoinTable(name = "course_student", joinColumns = @JoinColumn(name = "employee_id"), inverseJoinColumns = @JoinColumn(name = "address_id"))
	private List<Employee> employee;

	@Override
	public String toString() {
		return "Address [addr_id=" + addr_id + ", addr_line_one="
				+ addr_line_one + ", addr_line_two=" + addr_line_two
				+ ", city=" + city + ", employee=" + employee + "]";
	}
}
