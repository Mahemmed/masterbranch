package com.samplecode.springboot.cruddemo.dao;

import java.util.List;

import com.samplecode.springboot.cruddemo.entity.Employee;

public interface EmployeeDAO {

	public List<Employee> findAll();
	
	public Employee findById(Long theId);
	
	public void save(Employee theEmployee);
	
	public void deleteById(Long theId);
	
}
